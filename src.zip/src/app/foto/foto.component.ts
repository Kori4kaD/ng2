import { Component } from '@angular/core';

@Component({
  selector: 'app-foto',
  standalone: true,
  imports: [],
  templateUrl: './foto.component.html',
  styleUrl: './foto.component.css'
})
export class FotoComponent {
  imagePath="../../assets/images/foto.jpg";
}
