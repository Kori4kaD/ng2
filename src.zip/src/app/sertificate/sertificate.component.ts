import { Component } from '@angular/core';

@Component({
  selector: 'app-sertificate',
  standalone: true,
  imports: [],
  templateUrl: './sertificate.component.html',
  styleUrl: './sertificate.component.css'
})
export class SertificateComponent {

}
